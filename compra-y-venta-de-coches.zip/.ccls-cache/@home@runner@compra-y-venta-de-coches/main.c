#include <stdio.h>
#include <string.h>

// Definición de la estructura Vehiculo
typedef struct {
    int id;
    char marca[50];
    char modelo[50];
    int año;
    float precio;
} Vehiculo;

// Definición de la estructura Cliente
typedef struct {
    int id;
    char nombre[50];
    char direccion[100];
    char telefono[20];
} Cliente;

// Definición de la estructura Venta
typedef struct {
    int id;
    Vehiculo vehiculo;
    Cliente cliente;
    char fecha[20];
} Venta;

// Definición de la estructura Compra
typedef struct {
    int id;
    Vehiculo vehiculo;
    char fecha[20];
} Compra;

// Función principal
int main() {
    // Ejemplo de uso
    Vehiculo vehiculo1 = {1, "Toyota", "Corolla", 2022, 25000.0};
    Cliente cliente1 = {1, "Juan", "Calle 123", "123456789"};
    Venta venta1 = {1, vehiculo1, cliente1, "2024-04-04"};

    printf("Venta realizada:\n");
    printf("Vehiculo: %s %s\n", venta1.vehiculo.marca, venta1.vehiculo.modelo);
    printf("Cliente: %s\n", venta1.cliente.nombre);
    printf("Fecha: %s\n", venta1.fecha);

    return 0;
}

